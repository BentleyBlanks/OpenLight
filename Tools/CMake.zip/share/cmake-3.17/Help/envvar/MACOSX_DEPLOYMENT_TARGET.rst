MACOSX_DEPLOYMENT_TARGET
------------------------

.. include:: ENV_VAR.txt

Specify the minimum version of macOS on which the target binaries are
to be deployed.

The ``MACOSX_DEPLOYMENT_TARGET`` environment variable sets the default value for
the :variable:`CMAKE_OSX_DEPLOYMENT_TARGET` variable.
